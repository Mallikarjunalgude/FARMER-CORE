
  # AI Farming Assistant

  This is a code bundle for AI Farming Assistant. The original project is available at https://www.figma.com/design/Ae5PPleCqHA6cM9P3ceusI/AI-Farming-Assistant.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  