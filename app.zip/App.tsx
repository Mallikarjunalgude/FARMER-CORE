import { RouterProvider } from "react-router";
import { router } from "./routes";

export default function App() {
  return (
    <div 
      className="min-h-screen flex justify-center w-full font-sans antialiased text-gray-900 bg-cover bg-center bg-fixed"
      style={{ backgroundImage: "url('https://images.unsplash.com/photo-1759155895472-c4fd4716b158?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXNoJTIwZ3JlZW4lMjBhZ3JpY3VsdHVyZSUyMGZpZWxkJTIwZmFybWluZ3xlbnwxfHx8fDE3NzYzNjAyMzJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')" }}
    >
      <div className="fixed inset-0 bg-black/40 backdrop-blur-[2px] pointer-events-none"></div>
      <div className="w-full max-w-md bg-white/85 backdrop-blur-2xl min-h-screen shadow-2xl relative overflow-hidden flex flex-col z-10 sm:border-x border-white/20">
        <RouterProvider router={router} />
      </div>
    </div>
  );
}
