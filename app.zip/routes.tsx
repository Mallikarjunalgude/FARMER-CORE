import { createBrowserRouter } from "react-router";
import { Login } from "./pages/Login";
import { VerifyOTP } from "./pages/VerifyOTP";
import { Dashboard } from "./pages/Dashboard";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/verify",
    Component: VerifyOTP,
  },
  {
    path: "/dashboard",
    Component: Dashboard,
  },
]);
