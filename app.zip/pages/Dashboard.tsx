import { useState, useRef, useEffect } from "react";
import { 
  Home, Sprout, TrendingUp, MessageSquare, 
  CloudSun, Droplets, Wind, Thermometer, 
  AlertTriangle, ChevronRight, Mic, Send, 
  Volume2, Loader2, StopCircle, Globe, User, 
  Bug, Menu, Bell
} from "lucide-react";
import { clsx } from "clsx";
import { motion, AnimatePresence } from "motion/react";

type Tab = "home" | "crops" | "market" | "ai";

type Message = {
  id: string;
  sender: "user" | "bot";
  text: string;
  language?: string;
};

const SUGGESTIONS = [
  { id: 1, title: "Soil Health", icon: <Sprout className="w-5 h-5" />, prompt: "How can I improve my soil health before sowing wheat?", color: "text-amber-600", bg: "bg-amber-100/80" },
  { id: 2, title: "Irrigation", icon: <Droplets className="w-5 h-5" />, prompt: "What is the best irrigation schedule for cotton this week?", color: "text-blue-600", bg: "bg-blue-100/80" },
  { id: 3, title: "Pest Control", icon: <Bug className="w-5 h-5" />, prompt: "I see white bugs on my tomatoes. How do I treat them organically?", color: "text-red-500", bg: "bg-red-100/80" },
  { id: 4, title: "Crop Yield", icon: <TrendingUp className="w-5 h-5" />, prompt: "How can I maximize my sugarcane yield this season?", color: "text-emerald-600", bg: "bg-emerald-100/80" },
];

const INITIAL_GREETING: Record<string, string> = {
  en: "Namaste Ram! I am your Farmer Core Assistant. How can I help you with your farm today?",
  hi: "नमस्ते राम! मैं आपका Farmer Core सहायक हूँ। आज मैं आपकी खेती में कैसे मदद कर सकता हूँ?",
  mr: "नमस्कार राम! मी तुमचा Farmer Core सहाय्यक आहे. आज मी तुम्हाला तुमच्या शेतीत कशी मदत करू शकेन?",
  ta: "வணக்கம் ராம்! நான் உங்கள் Farmer Core உதவியாளர். இன்று நான் உங்களுக்கு எப்படி உதவ முடியும்?",
  kn: "ನಮಸ್ಕಾರ ರಾಮ್! ನಾನು ನಿಮ್ಮ Farmer Core ಸಹಾಯಕ. ಇಂದು ನಾನು ನಿಮ್ಮ ಕೃಷಿಯಲ್ಲಿ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?",
};

export function Dashboard() {
  const [activeTab, setActiveTab] = useState<Tab>("home");
  const [language, setLanguage] = useState("en");
  const [messages, setMessages] = useState<Message[]>([
    { id: "1", sender: "bot", text: INITIAL_GREETING["en"], language: "en" }
  ]);
  const [input, setInput] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingId, setIsPlayingId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeTab === "ai" && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping, activeTab]);

  const handleLanguageChange = (lang: string) => {
    setLanguage(lang);
    setMessages([{ id: Date.now().toString(), sender: "bot", text: INITIAL_GREETING[lang], language: lang }]);
  };

  const simulateBotResponse = (userText: string) => {
    setIsTyping(true);
    setTimeout(() => {
      let botResponse = "I can definitely help with that. Based on typical agricultural practices, ensure you maintain proper soil moisture and monitor for early signs of pests. Let me know if you need specific fertilizer recommendations.";
      if (userText.toLowerCase().includes("soil")) botResponse = "To improve soil health, consider adding organic compost and practicing crop rotation. Testing your soil pH and NPK levels is highly recommended before the next sowing season.";
      if (userText.toLowerCase().includes("irrigation") || userText.toLowerCase().includes("water")) botResponse = "For irrigation, drip systems are highly efficient. Currently, the weather is dry, so ensure your crops get water early morning or late evening to minimize evaporation.";
      if (userText.toLowerCase().includes("pest") || userText.toLowerCase().includes("bug")) botResponse = "For white bugs (likely aphids or whiteflies), you can spray Neem oil mixed with mild soap water. It is organic and very effective if applied every 5-7 days.";
      if (userText.toLowerCase().includes("yield")) botResponse = "To maximize yield, ensure timely application of fertilizers, maintain weed-free fields, and use high-quality seeds. Real-time weather monitoring also helps in planning harvests.";
      
      if (language === "hi") botResponse = "मैं इसमें आपकी मदद कर सकता हूँ। अपनी मिट्टी के स्वास्थ्य के लिए जैविक खाद का उपयोग करें और नमी बनाए रखें।";
      if (language === "mr") botResponse = "मी नक्कीच मदत करू शकतो. मातीचे आरोग्य सुधारण्यासाठी सेंद्रिय खतांचा वापर करा.";
      if (language === "ta") botResponse = "நான் நிச்சயமாக உதவ முடியும். மண் வளத்தை மேம்படுத்த இயற்கை உரங்களை பயன்படுத்தவும்.";
      if (language === "kn") botResponse = "ನಾನು ಖಂಡಿತವಾಗಿಯೂ ಸಹಾಯ ಮಾಡಬಲ್ಲೆ. ಮಣ್ಣಿನ ಆರೋಗ್ಯವನ್ನು ಸುಧಾರಿಸಲು ಸಾವಯವ ಗೊಬ್ಬರವನ್ನು ಬಳಸಿ.";

      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        sender: "bot",
        text: botResponse,
        language
      }]);
      setIsTyping(false);
    }, 1500);
  };

  const handleSend = (text: string) => {
    if (!text.trim()) return;
    setMessages(prev => [...prev, { id: Date.now().toString(), sender: "user", text }]);
    setInput("");
    simulateBotResponse(text);
  };

  const toggleVoicePlay = (id: string) => {
    if (isPlayingId === id) {
      setIsPlayingId(null);
    } else {
      setIsPlayingId(id);
      setTimeout(() => setIsPlayingId(null), 3000);
    }
  };

  const toggleRecording = () => {
    if (isRecording) {
      setIsRecording(false);
      handleSend("What is the weather forecast for tomorrow?");
    } else {
      setIsRecording(true);
    }
  };

  // Content for Home Tab
  const renderHome = () => (
    <div className="flex-1 overflow-y-auto pb-24 px-4 pt-6 space-y-6 animate-in fade-in zoom-in-95 duration-300">
      <div className="flex justify-between items-center mb-2">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Ram's Farm</h2>
          <p className="text-sm text-gray-600 font-medium">Cotton & Sugarcane fields</p>
        </div>
        <button className="p-2.5 bg-white/50 backdrop-blur-md rounded-full shadow-sm border border-white/60 text-gray-700 relative hover:bg-white/80 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2.5 w-2 h-2 bg-red-500 rounded-full border border-white"></span>
        </button>
      </div>

      {/* Weather Card */}
      <div className="bg-gradient-to-br from-blue-500/90 to-blue-600/90 backdrop-blur-xl rounded-3xl p-5 text-white shadow-lg border border-blue-400/30">
        <div className="flex justify-between items-start mb-4">
          <div>
            <p className="text-blue-100 text-sm font-medium mb-1">Today's Forecast</p>
            <div className="flex items-end gap-2">
              <h3 className="text-4xl font-bold tracking-tighter">32°C</h3>
              <span className="text-blue-100 font-medium pb-1">Pune</span>
            </div>
          </div>
          <CloudSun className="w-12 h-12 text-yellow-300 drop-shadow-md" />
        </div>
        
        <div className="grid grid-cols-3 gap-3 pt-4 border-t border-blue-400/30">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-blue-100">
              <Droplets className="w-3.5 h-3.5" />
              <span className="text-xs">Humidity</span>
            </div>
            <p className="font-semibold text-sm">65%</p>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-blue-100">
              <Wind className="w-3.5 h-3.5" />
              <span className="text-xs">Wind</span>
            </div>
            <p className="font-semibold text-sm">12 km/h</p>
          </div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-1.5 text-blue-100">
              <Thermometer className="w-3.5 h-3.5" />
              <span className="text-xs">Soil Temp</span>
            </div>
            <p className="font-semibold text-sm">28°C</p>
          </div>
        </div>
      </div>

      {/* Farm Status */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider px-1">Farm Status</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white/60 backdrop-blur-lg border border-white/50 p-4 rounded-2xl shadow-sm flex flex-col gap-2">
            <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mb-1">
              <Droplets className="w-4 h-4" />
            </div>
            <p className="text-xs text-gray-500 font-semibold">Soil Moisture</p>
            <p className="text-lg font-bold text-gray-800">42% <span className="text-xs font-semibold text-orange-500 bg-orange-100 px-1.5 py-0.5 rounded-md ml-1">Low</span></p>
          </div>
          <div className="bg-white/60 backdrop-blur-lg border border-white/50 p-4 rounded-2xl shadow-sm flex flex-col gap-2">
            <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mb-1">
              <Bug className="w-4 h-4" />
            </div>
            <p className="text-xs text-gray-500 font-semibold">Pest Risk</p>
            <p className="text-lg font-bold text-gray-800">Low <span className="text-xs font-semibold text-emerald-600 bg-emerald-100 px-1.5 py-0.5 rounded-md ml-1">Safe</span></p>
          </div>
        </div>
      </div>

      {/* Actionable Alerts */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-gray-800 uppercase tracking-wider px-1">Today's Tasks</h3>
        <div className="bg-white/70 backdrop-blur-md border border-red-100/50 p-4 rounded-2xl shadow-sm flex gap-3 items-start relative overflow-hidden">
          <div className="absolute left-0 top-0 bottom-0 w-1.5 bg-red-400"></div>
          <div className="p-2 bg-red-100/80 rounded-xl text-red-600 shrink-0">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-bold text-gray-900 text-[15px]">Irrigate Cotton Field</h4>
            <p className="text-xs text-gray-600 leading-relaxed mt-1 mb-2">Soil moisture has dropped below optimal levels. Recommended to run drip irrigation for 2 hours today.</p>
            <button className="text-xs font-bold text-red-600 uppercase tracking-wide flex items-center gap-1 hover:text-red-700">
              Mark Complete <ChevronRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );

  // Content for AI Guide Tab
  const renderAIGuide = () => (
    <div className="flex flex-col h-full animate-in fade-in zoom-in-95 duration-300 relative">
      <div className="bg-white/60 backdrop-blur-md border-b border-white/40 p-4 flex items-center gap-3 shrink-0 z-10 shadow-sm">
        <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-emerald-600 rounded-full flex items-center justify-center shadow-md">
          <MessageSquare className="w-5 h-5 text-white" />
        </div>
        <div className="flex-1">
          <h2 className="font-bold text-gray-900 leading-tight">Farmer Core AI</h2>
          <p className="text-xs text-emerald-600 font-semibold">Online • Ready to help</p>
        </div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-6 scroll-smooth"
      >
        <div className="grid grid-cols-2 gap-2 mb-6">
          {SUGGESTIONS.map((item) => (
            <button
              key={item.id}
              onClick={() => handleSend(item.prompt)}
              className="bg-white/70 backdrop-blur-sm p-3 rounded-2xl shadow-sm border border-white/60 flex flex-col items-start gap-2 hover:shadow-md transition-all text-left active:scale-95"
            >
              <div className={clsx("p-1.5 rounded-lg", item.bg, item.color)}>
                {item.icon}
              </div>
              <span className="font-semibold text-gray-800 text-xs leading-tight">{item.title}</span>
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-4">
          <AnimatePresence>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className={clsx(
                  "flex w-full",
                  msg.sender === "user" ? "justify-end" : "justify-start"
                )}
              >
                <div 
                  className={clsx(
                    "max-w-[85%] rounded-2xl p-4 shadow-sm backdrop-blur-md",
                    msg.sender === "user" 
                      ? "bg-emerald-600 text-white rounded-br-sm border border-emerald-500/50" 
                      : "bg-white/80 border border-white text-gray-800 rounded-bl-sm"
                  )}
                >
                  <p className="text-[14px] leading-relaxed mb-1">{msg.text}</p>
                  
                  {msg.sender === "bot" && (
                    <div className="flex justify-end mt-2 pt-2 border-t border-gray-200/50">
                      <button 
                        onClick={() => toggleVoicePlay(msg.id)}
                        className={clsx(
                          "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-colors",
                          isPlayingId === msg.id 
                            ? "bg-emerald-100 text-emerald-700" 
                            : "bg-black/5 text-gray-600 hover:bg-black/10"
                        )}
                      >
                        {isPlayingId === msg.id ? (
                          <>
                            <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                            <span>Playing...</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3.5 h-3.5" />
                            <span>Listen</span>
                          </>
                        )}
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
              <div className="bg-white/80 backdrop-blur-md border border-white text-gray-500 rounded-2xl rounded-bl-sm p-4 shadow-sm flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-500" />
                <span className="text-sm font-medium">Thinking...</span>
              </div>
            </motion.div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="p-4 bg-gradient-to-t from-white/90 via-white/70 to-transparent backdrop-blur-sm z-20 pb-[90px]">
        <form 
          onSubmit={(e) => { e.preventDefault(); handleSend(input); }}
          className="flex items-end gap-2 max-w-md mx-auto relative bg-white rounded-3xl p-1.5 shadow-lg border border-gray-200/60"
        >
          <div className="flex-1 flex items-center overflow-hidden pl-3">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask AI anything..."
              className="w-full py-2.5 outline-none text-[15px] bg-transparent text-gray-800 font-medium placeholder-gray-400"
            />
          </div>
          
          {input.trim() ? (
            <button 
              type="submit"
              className="w-11 h-11 bg-emerald-600 text-white rounded-full flex items-center justify-center flex-shrink-0 hover:bg-emerald-700 transition-colors shadow-sm active:scale-95"
            >
              <Send className="w-4 h-4 ml-0.5" />
            </button>
          ) : (
            <button 
              type="button"
              onClick={toggleRecording}
              className={clsx(
                "w-11 h-11 rounded-full flex items-center justify-center flex-shrink-0 transition-all shadow-sm active:scale-95",
                isRecording 
                  ? "bg-red-500 text-white animate-pulse shadow-red-500/30" 
                  : "bg-emerald-100 text-emerald-700 hover:bg-emerald-200"
              )}
            >
              {isRecording ? <StopCircle className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>
          )}
        </form>
        {isRecording && (
          <div className="text-center mt-2 text-xs font-bold text-red-500 animate-pulse drop-shadow-sm">
            Listening... Tap to stop.
          </div>
        )}
      </div>
    </div>
  );

  // Content for Market Tab
  const renderMarket = () => (
    <div className="flex-1 overflow-y-auto pb-24 px-4 pt-6 space-y-6 animate-in fade-in zoom-in-95 duration-300">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Mandi Prices</h2>
          <p className="text-sm text-gray-600 font-medium">Pune APMC Market</p>
        </div>
        <p className="text-xs font-semibold text-emerald-600 bg-emerald-100 px-2 py-1 rounded-md">Live</p>
      </div>

      <div className="space-y-3">
        {[
          { name: "Cotton", type: "Long Staple", price: "₹7,200", change: "+2.4%", trend: "up", colorClass: "text-emerald-500" },
          { name: "Wheat", type: "Lokwan", price: "₹2,450", change: "+0.8%", trend: "up", colorClass: "text-emerald-500" },
          { name: "Sugarcane", type: "FRP", price: "₹315", change: "0.0%", trend: "neutral", colorClass: "text-gray-500" },
          { name: "Soybean", type: "Yellow", price: "₹4,600", change: "-1.2%", trend: "down", colorClass: "text-red-500" },
          { name: "Onion", type: "Red", price: "₹1,800", change: "+12.5%", trend: "up", colorClass: "text-emerald-500" },
        ].map((item, i) => (
          <div key={i} className="bg-white/70 backdrop-blur-md border border-white/50 p-4 rounded-2xl shadow-sm flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                <TrendingUp className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-gray-900 text-[15px]">{item.name}</h4>
                <p className="text-xs text-gray-500 font-medium">{item.type} • per quintal</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold text-gray-900 text-[16px]">{item.price}</p>
              <p className={clsx("text-xs font-bold", item.colorClass)}>{item.change}</p>
            </div>
          </div>
        ))}
      </div>
      
      <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-4 mt-6">
        <p className="text-sm text-emerald-800 font-medium text-center">
          Ask AI Guide for market price predictions and best time to sell your produce.
        </p>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col flex-1 h-full bg-transparent overflow-hidden relative">
      {/* Dynamic Header actions (Language selection overlay) */}
      <div className="absolute top-4 right-4 z-50">
        <div className="relative group">
          <button className="flex items-center gap-1.5 bg-white/70 backdrop-blur-md border border-white/50 hover:bg-white/90 px-3 py-1.5 rounded-full text-xs font-bold text-gray-800 shadow-sm transition-colors">
            <Globe className="w-3.5 h-3.5" />
            <span className="uppercase">{language}</span>
          </button>
          
          <div className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden hidden group-hover:block w-32 origin-top-right">
            {Object.entries({ en: "English", hi: "हिंदी", mr: "मराठी", ta: "தமிழ்", kn: "ಕನ್ನಡ" }).map(([code, name]) => (
              <button
                key={code}
                onClick={() => handleLanguageChange(code)}
                className={clsx(
                  "w-full text-left px-4 py-2.5 text-sm hover:bg-emerald-50 transition-colors",
                  language === code ? "text-emerald-700 font-bold bg-emerald-50/50" : "text-gray-700 font-medium"
                )}
              >
                {name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Area Content */}
      <div className="flex-1 overflow-hidden relative flex flex-col">
        {activeTab === "home" && renderHome()}
        {activeTab === "ai" && renderAIGuide()}
        {activeTab === "market" && renderMarket()}
        {activeTab === "crops" && (
          <div className="flex-1 h-full flex items-center justify-center p-6 text-center animate-in fade-in zoom-in-95 duration-300">
            <div>
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sprout className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">My Crops</h3>
              <p className="text-gray-600 text-sm max-w-xs mx-auto mb-6">Track growth stages, irrigation schedules, and get personalized tips.</p>
              <button className="bg-emerald-600 text-white font-bold py-2.5 px-6 rounded-full shadow-md hover:bg-emerald-700 active:scale-95 transition-all">
                + Add New Crop
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Navigation */}
      <div className="absolute bottom-0 left-0 right-0 bg-white/85 backdrop-blur-2xl border-t border-white/50 px-6 py-2 pb-safe flex justify-between items-center z-40 shadow-[0_-10px_40px_-15px_rgba(0,0,0,0.1)]">
        {[
          { id: "home", label: "Home", icon: Home },
          { id: "crops", label: "Crops", icon: Sprout },
          { id: "market", label: "Mandi", icon: TrendingUp },
          { id: "ai", label: "AI Guide", icon: MessageSquare },
        ].map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button 
              key={tab.id}
              onClick={() => setActiveTab(tab.id as Tab)}
              className="flex flex-col items-center justify-center gap-1 w-16 py-2 relative"
            >
              {isActive && (
                <motion.div layoutId="nav-indicator" className="absolute top-0 w-10 h-1 bg-emerald-500 rounded-b-full shadow-[0_2px_8px_rgba(16,185,129,0.5)]"></motion.div>
              )}
              <Icon className={clsx("w-6 h-6 transition-all duration-300", isActive ? "text-emerald-600 scale-110" : "text-gray-400")} />
              <span className={clsx("text-[10px] font-bold transition-all", isActive ? "text-emerald-700" : "text-gray-400")}>{tab.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
