import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, CheckCircle2 } from "lucide-react";

export function VerifyOTP() {
  const [otp, setOtp] = useState(["", "", "", ""]);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    inputRefs.current[0]?.focus();
  }, []);

  const handleChange = (index: number, value: string) => {
    if (value.length > 1) return;
    if (!/^\d*$/.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto focus next
    if (value !== "" && index < 3) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && index > 0 && otp[index] === "") {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (otp.join("").length === 4) {
      navigate("/dashboard");
    }
  };

  return (
    <div className="flex-1 flex flex-col p-6 h-full relative bg-transparent">
      <button 
        onClick={() => navigate("/")} 
        className="w-10 h-10 -ml-2 rounded-full flex items-center justify-center hover:bg-gray-100 mb-8 transition-colors"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
      </button>
      
      <div className="flex-1">
        <h1 className="text-3xl font-bold text-gray-900 mb-3">Verify OTP</h1>
        <p className="text-gray-500 mb-8 leading-relaxed">
          We've sent a 4-digit verification code to your mobile number ending in <span className="font-semibold text-gray-700">XXXX</span>.
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col gap-6 w-full max-w-sm">
          <div className="flex gap-4 justify-between max-w-xs mb-4">
            {otp.map((digit, idx) => (
              <input
                key={idx}
                ref={el => inputRefs.current[idx] = el}
                type="text"
                inputMode="numeric"
                pattern="[0-9]*"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(idx, e.target.value)}
                onKeyDown={(e) => handleKeyDown(idx, e)}
                className="w-16 h-16 text-center text-3xl font-bold bg-white border-2 rounded-2xl border-gray-200 focus:border-emerald-500 focus:ring-4 focus:ring-emerald-100 outline-none transition-all"
              />
            ))}
          </div>

          <button
            type="submit"
            disabled={otp.join("").length !== 4}
            className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 disabled:cursor-not-allowed text-white font-semibold py-4 rounded-xl transition-colors flex items-center justify-center gap-2 shadow-sm"
          >
            <CheckCircle2 className="w-5 h-5" />
            Verify & Proceed
          </button>
          
          <div className="text-center mt-6">
            <span className="text-gray-500 text-sm">Didn't receive the code? </span>
            <button type="button" className="text-emerald-600 font-semibold text-sm hover:underline">
              Resend SMS
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
