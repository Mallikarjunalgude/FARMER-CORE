import { useState } from "react";
import { useNavigate } from "react-router";
import { Phone, Leaf } from "lucide-react";

export function Login() {
  const [phone, setPhone] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length === 10) {
      navigate("/verify");
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 text-center bg-transparent h-full relative">
      <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
        <Leaf className="w-10 h-10 text-emerald-600" />
      </div>
      
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Farmer Core</h1>
      <p className="text-gray-500 mb-8 text-sm">Your personal farming guide. Login to get started.</p>

      <form onSubmit={handleSubmit} className="w-full max-w-sm flex flex-col gap-4">
        <div className="flex flex-col text-left gap-1">
          <label className="text-sm font-medium text-gray-700">Mobile Number</label>
          <div className="flex bg-white rounded-xl border border-gray-300 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-200 overflow-hidden transition-all">
            <div className="flex items-center justify-center px-4 border-r border-gray-300 bg-gray-50 text-gray-600 font-medium">
              +91
            </div>
            <input
              type="tel"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
              placeholder="98765 43210"
              className="w-full p-3.5 outline-none text-gray-900 font-medium tracking-wide placeholder:font-normal placeholder:tracking-normal"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={phone.length !== 10}
          className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-300 disabled:cursor-not-allowed text-white font-semibold py-3.5 rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          <Phone className="w-5 h-5" />
          Get OTP
        </button>
      </form>

      <div className="mt-8 text-sm text-gray-500 flex items-center justify-center gap-2 flex-wrap">
        <span>Available in:</span>
        <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-medium text-xs">English</span>
        <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-medium text-xs">हिंदी</span>
        <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-medium text-xs">मराठी</span>
        <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-medium text-xs">தமிழ்</span>
        <span className="bg-emerald-50 text-emerald-700 px-2 py-1 rounded font-medium text-xs">ಕನ್ನಡ</span>
      </div>
    </div>
  );
}
